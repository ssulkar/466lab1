# Lab1 
Devon Martin, Shiv Sulkar, Robert Weber

# Usage
Usage: python lab1.py filename minsup minconf
