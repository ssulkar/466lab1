#Lab2
Authors: Devon Martin, Shiv Sulkar
Emails:
- dmart112@calpoly.edu
- ssulkr@calpoly.edu

#Usage

##C45 Training Algorithm
python3 InduceC45.py <domain.xml> <training_set.csv> [<restrictions.csv>]

##Classifier
python3 Classifier.py <records.csv> <tree.xml>

##Evaluation
python3 Validation.py <training_set.csv> <n> [<restrictions.csv>]
